export default function Error () {
    return (
        <p>404 Page not found 😱</p>
    )
}